import React from 'react';
import {
  CheckCircle2,
  Clock,
  Download,
  Eye,
  FileEdit,
  FilePlus2,
  Search,
  Trash2,
} from 'lucide-react';
import {
  ActionStatus,
  AttendanceStatus,
  MeetingMinute,
  MeetingStatus,
} from '../types/notulen';
import { formatTanggalIndonesia } from '../utils/htmlExporter';

interface MinutesListViewProps {
  minutes: MeetingMinute[];
  searchQuery: string;
  onSearchChange: (value: string) => void;
  statusFilter: 'ALL' | MeetingStatus;
  onStatusFilterChange: (status: 'ALL' | MeetingStatus) => void;
  selectedUnit: string;
  onCreateNew: () => void;
  onOpenMinute: (id: string, mode: 'edit' | 'preview') => void;
  onDownloadHtml: (minute: MeetingMinute) => void;
  onRequestDelete: (minute: MeetingMinute) => void;
}

export const MinutesListView: React.FC<MinutesListViewProps> = ({
  minutes,
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  selectedUnit,
  onCreateNew,
  onOpenMinute,
  onDownloadHtml,
  onRequestDelete,
}) => {
  const totalMinutes = minutes.length;
  const approvedCount = minutes.filter((m) => m.status === MeetingStatus.FINAL).length;
  const allActions = minutes.flatMap((m) => m.actionItems);
  const pendingActions = allActions.filter((a) => a.status !== ActionStatus.SELESAI).length;
  const totalHadir = minutes.reduce(
    (sum, m) => sum + m.attendees.filter((a) => a.status === AttendanceStatus.HADIR).length,
    0
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Arsip &amp; Tata Kelola Rapat · {selectedUnit === 'ALL' ? 'Seluruh Unit Kerja' : selectedUnit}
          </p>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1 text-balance">
            Daftar Notulensi Rapat Universitas
          </h1>
        </div>
        <button
          type="button"
          onClick={onCreateNew}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <FilePlus2 className="w-4 h-4" />
          <span>Buat Notulen Baru</span>
        </button>
      </div>

      {/* KPI Strip: Single-level hairline borders, tabular numerals */}
      <div className="grid grid-cols-2 lg:grid-cols-4 bg-white border border-slate-200 rounded-lg divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Total Dokumen Notulen</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1 tabular-nums font-mono">
            {totalMinutes}
          </p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Telah Disahkan</p>
          <p className="text-2xl font-semibold text-emerald-700 mt-1 tabular-nums font-mono">
            {approvedCount}
          </p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Tindak Lanjut Terbuka</p>
          <p className="text-2xl font-semibold text-amber-700 mt-1 tabular-nums font-mono">
            {pendingActions}
          </p>
        </div>
        <div className="p-4 sm:p-5">
          <p className="text-xs font-medium text-slate-500">Akumulasi Kehadiran</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1 tabular-nums font-mono">
            {totalHadir}
          </p>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Cari nomor surat, judul rapat, pimpinan, atau lokasi..."
            aria-label="Cari notulensi rapat"
            className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
          />
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg self-start md:self-auto">
          {(['ALL', MeetingStatus.DRAFT, MeetingStatus.FINAL] as const).map((tab) => {
            const isActive = statusFilter === tab;
            const label = tab === 'ALL' ? 'Semua Status' : tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => onStatusFilterChange(tab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* High-density Document List */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        {minutes.length === 0 ? (
          <div className="py-16 px-6 text-center">
            <p className="text-base font-semibold text-slate-900">
              Tidak ada notulensi yang sesuai filter
            </p>
            <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
              Ubah kata kunci pencarian atau buat dokumen notulensi rapat baru untuk Universitas Mega Buana Palopo.
            </p>
            <button
              type="button"
              onClick={onCreateNew}
              className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap cursor-pointer"
            >
              <FilePlus2 className="w-4 h-4" />
              <span>Buat Notulen Pertama</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {minutes.map((minute) => {
              const hadirCount = minute.attendees.filter(
                (a) => a.status === AttendanceStatus.HADIR
              ).length;
              const isFinal = minute.status === MeetingStatus.FINAL;

              return (
                <div
                  key={minute.id}
                  className="p-4 sm:p-5 hover:bg-slate-50/80 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500">
                      <span className="font-mono font-medium text-[#0F294A] tabular-nums">
                        {minute.nomorSurat || 'Tanpa Nomor'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{minute.unitKerja}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        {formatTanggalIndonesia(minute.tanggal, true)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1 font-medium">
                        {isFinal ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                            <span className="text-emerald-700">Disahkan</span>
                          </>
                        ) : (
                          <>
                            <Clock className="w-3.5 h-3.5 text-amber-700" />
                            <span className="text-amber-700">Draf</span>
                          </>
                        )}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenMinute(minute.id, 'edit')}
                      className="text-left block group cursor-pointer"
                    >
                      <h2 className="text-base font-semibold text-slate-900 group-hover:text-[#0F294A] transition-colors">
                        {minute.judul || 'Notulensi Rapat Tanpa Judul'}
                      </h2>
                    </button>

                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-600">
                      <span>Pimpinan: {minute.pimpinanRapat || '-'}</span>
                      <span aria-hidden="true">·</span>
                      <span>Notulis: {minute.notulis || '-'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        {hadirCount}/{minute.attendees.length} Hadir
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{minute.agendas.length} Agenda</span>
                    </div>
                  </div>

                  {/* Row Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenMinute(minute.id, 'edit')}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <FileEdit className="w-3.5 h-3.5" />
                      <span>Sunting</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenMinute(minute.id, 'preview')}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Pratinjau</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDownloadHtml(minute)}
                      title="Unduh Dokumen HTML"
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#0F294A] bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>HTML</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onRequestDelete(minute)}
                      title="Hapus Notulen"
                      aria-label={`Hapus notulen ${minute.judul}`}
                      className="inline-flex items-center justify-center p-2 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors shrink-0 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
