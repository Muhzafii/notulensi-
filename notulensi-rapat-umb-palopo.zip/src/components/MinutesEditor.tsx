import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Check,
  Code2,
  Columns2,
  Download,
  FileEdit,
  Eye,
  Plus,
  Printer,
  Trash2,
} from 'lucide-react';
import {
  ActionItem,
  ActionPriority,
  ActionStatus,
  AgendaItem,
  AttendanceStatus,
  Attendee,
  JENIS_RAPAT_LIST,
  MeetingMinute,
  MeetingStatus,
  UNIT_KERJA_LIST,
} from '../types/notulen';
import { generateStandaloneHtml } from '../utils/htmlExporter';
import { FormalDocumentPreview } from './FormalDocumentPreview';

interface MinutesEditorProps {
  minute: MeetingMinute;
  initialMode?: 'edit' | 'preview';
  onChange: (updated: MeetingMinute) => void;
  onBack: () => void;
  onDownloadHtml: (minute: MeetingMinute) => void;
  onNotify: (message: string) => void;
}

type EditorTab = 'identitas' | 'peserta' | 'agenda' | 'tindaklanjut' | 'pengesahan';

const ROMAN_MONTHS = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];

export const MinutesEditor: React.FC<MinutesEditorProps> = ({
  minute,
  initialMode = 'edit',
  onChange,
  onBack,
  onDownloadHtml,
  onNotify,
}) => {
  const [viewMode, setViewMode] = useState<'edit' | 'preview' | 'split'>(initialMode);
  const [activeTab, setActiveTab] = useState<EditorTab>('identitas');
  const [copiedHtml, setCopiedHtml] = useState(false);

  const updateField = <K extends keyof MeetingMinute>(key: K, value: MeetingMinute[K]) => {
    onChange({
      ...minute,
      [key]: value,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleGenerateNomor = () => {
    const dateParts = minute.tanggal ? minute.tanggal.split('-') : [];
    const monthNum = dateParts.length === 3 ? parseInt(dateParts[1], 10) : new Date().getMonth() + 1;
    const yearNum = dateParts.length === 3 ? dateParts[0] : String(new Date().getFullYear());
    const roman = ROMAN_MONTHS[(monthNum - 1 + 12) % 12] || 'XI';

    let unitCode = 'UMB';
    if (minute.unitKerja.includes('Rektorat')) unitCode = 'SENAT';
    else if (minute.unitKerja.includes('Kesehatan')) unitCode = 'FKES';
    else if (minute.unitKerja.includes('Ekonomi')) unitCode = 'FEB';
    else if (minute.unitKerja.includes('Sains')) unitCode = 'FST';
    else if (minute.unitKerja.includes('Pascasarjana')) unitCode = 'PASCA';
    else if (minute.unitKerja.includes('LPM')) unitCode = 'LPM';
    else if (minute.unitKerja.includes('LPPM')) unitCode = 'LPPM';
    else if (minute.unitKerja.includes('Biro')) unitCode = 'BAAK';

    const seq = String(Math.floor(10 + Math.random() * 89)).padStart(3, '0');
    updateField('nomorSurat', `${seq}/NOT-${unitCode}/UMB-PLP/${roman}/${yearNum}`);
  };

  // Attendee handlers
  const addAttendee = () => {
    const newAtt: Attendee = {
      id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      nama: '',
      jabatan: '',
      status: AttendanceStatus.HADIR,
    };
    updateField('attendees', [...minute.attendees, newAtt]);
  };

  const updateAttendee = (id: string, patch: Partial<Attendee>) => {
    updateField(
      'attendees',
      minute.attendees.map((a) => (a.id === id ? { ...a, ...patch } : a))
    );
  };

  const removeAttendee = (id: string) => {
    updateField(
      'attendees',
      minute.attendees.filter((a) => a.id !== id)
    );
  };

  // Agenda handlers
  const addAgenda = () => {
    const newAg: AgendaItem = {
      id: `ag-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      judul: '',
      pembicara: '',
      pembahasan: '',
      keputusan: '',
    };
    updateField('agendas', [...minute.agendas, newAg]);
  };

  const updateAgenda = (id: string, patch: Partial<AgendaItem>) => {
    updateField(
      'agendas',
      minute.agendas.map((ag) => (ag.id === id ? { ...ag, ...patch } : ag))
    );
  };

  const moveAgenda = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= minute.agendas.length) return;
    const copy = [...minute.agendas];
    const [removed] = copy.splice(index, 1);
    copy.splice(target, 0, removed);
    updateField('agendas', copy);
  };

  const removeAgenda = (id: string) => {
    updateField(
      'agendas',
      minute.agendas.filter((ag) => ag.id !== id)
    );
  };

  // Action item handlers
  const addActionItem = () => {
    const newAct: ActionItem = {
      id: `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      tugas: '',
      penanggungJawab: '',
      tenggat: minute.tanggal,
      prioritas: ActionPriority.SEDANG,
      status: ActionStatus.BELUM_MULAI,
    };
    updateField('actionItems', [...minute.actionItems, newAct]);
  };

  const updateActionItem = (id: string, patch: Partial<ActionItem>) => {
    updateField(
      'actionItems',
      minute.actionItems.map((act) => (act.id === id ? { ...act, ...patch } : act))
    );
  };

  const removeActionItem = (id: string) => {
    updateField(
      'actionItems',
      minute.actionItems.filter((act) => act.id !== id)
    );
  };

  const handleCopyHtml = async () => {
    try {
      const html = generateStandaloneHtml(minute);
      await navigator.clipboard.writeText(html);
      setCopiedHtml(true);
      onNotify('Kode HTML notulensi berhasil disalin ke papan klip.');
      setTimeout(() => setCopiedHtml(false), 2000);
    } catch {
      onNotify('Gagal menyalin ke papan klip. Gunakan tombol Unduh HTML.');
    }
  };

  const handlePrint = () => {
    if (viewMode === 'edit') {
      setViewMode('preview');
      setTimeout(() => window.print(), 120);
    } else {
      window.print();
    }
  };

  const sectionTabs: { id: EditorTab; label: string; count?: number }[] = [
    { id: 'identitas', label: '01. Identitas Rapat' },
    { id: 'peserta', label: '02. Daftar Hadir', count: minute.attendees.length },
    { id: 'agenda', label: '03. Pembahasan Agenda', count: minute.agendas.length },
    { id: 'tindaklanjut', label: '04. Tindak Lanjut', count: minute.actionItems.length },
    { id: 'pengesahan', label: '05. Pengesahan' },
  ];

  return (
    <div className="space-y-5">
      {/* Workspace Toolbar (Hidden on Print) */}
      <div className="no-print flex flex-col xl:flex-row xl:items-center justify-between gap-3 pb-4 border-b border-slate-200">
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Kembali</span>
          </button>

          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg">
            <button
              type="button"
              onClick={() => setViewMode('edit')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'edit'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileEdit className="w-3.5 h-3.5" />
              <span>Sunting</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('preview')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'preview'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Pratinjau Surat</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('split')}
              className={`hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'split'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns2 className="w-3.5 h-3.5" />
              <span>Split View</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={minute.status}
            onChange={(e) => updateField('status', e.target.value as MeetingStatus)}
            aria-label="Status Dokumen Notulen"
            className="px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 cursor-pointer"
          >
            <option value={MeetingStatus.DRAFT}>Status: Draf</option>
            <option value={MeetingStatus.FINAL}>Status: Disahkan</option>
          </select>

          <button
            type="button"
            onClick={handleCopyHtml}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copiedHtml ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Code2 className="w-3.5 h-3.5" />}
            <span>{copiedHtml ? 'HTML Disalin' : 'Salin HTML'}</span>
          </button>

          <button
            type="button"
            onClick={() => onDownloadHtml(minute)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh HTML</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak / PDF</span>
          </button>
        </div>
      </div>

      {/* Main Editor / Preview Area */}
      <div
        className={
          viewMode === 'split'
            ? 'grid grid-cols-1 xl:grid-cols-12 gap-6 items-start'
            : 'block'
        }
      >
        {/* Editor Pane */}
        {(viewMode === 'edit' || viewMode === 'split') && (
          <div
            className={`no-print bg-white border border-slate-200 rounded-lg overflow-hidden ${
              viewMode === 'split' ? 'xl:col-span-6' : 'max-w-4xl mx-auto'
            }`}
          >
            {/* Section Navigation */}
            <div className="flex items-center gap-1 overflow-x-auto border-b border-slate-200 bg-slate-50/70 px-3 py-2">
              {sectionTabs.map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'bg-white text-[#0F294A] border border-slate-200 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {tab.label}
                    {typeof tab.count === 'number' && (
                      <span className="ml-1.5 font-mono tabular-nums text-slate-400">
                        ({tab.count})
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="p-5 sm:p-7">
              {/* TAB 1: IDENTITAS RAPAT */}
              {activeTab === 'identitas' && (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Identitas &amp; Administrasi Rapat
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Informasi ini dicetak langsung pada Kop Surat dan kepala dokumen resmi UMB Palopo.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Judul / Perihal Rapat
                      </label>
                      <input
                        type="text"
                        value={minute.judul}
                        onChange={(e) => updateField('judul', e.target.value)}
                        placeholder="Contoh: Rapat Evaluasi Persiapan Akreditasi Program Studi..."
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs font-medium text-slate-700">
                          Nomor Dokumen Notulen
                        </label>
                        <button
                          type="button"
                          onClick={handleGenerateNomor}
                          className="text-[11px] font-medium text-[#0F294A] hover:underline cursor-pointer"
                        >
                          Buat Nomor Otomatis
                        </button>
                      </div>
                      <input
                        type="text"
                        value={minute.nomorSurat}
                        onChange={(e) => updateField('nomorSurat', e.target.value)}
                        placeholder="042/NOT-SENAT/UMB-PLP/XI/2026"
                        className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Unit Kerja / Fakultas Penyelenggara
                      </label>
                      <select
                        value={minute.unitKerja}
                        onChange={(e) => updateField('unitKerja', e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      >
                        {UNIT_KERJA_LIST.map((u) => (
                          <option key={u} value={u}>
                            {u}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Jenis Rapat
                      </label>
                      <select
                        value={minute.jenisRapat}
                        onChange={(e) => updateField('jenisRapat', e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      >
                        {JENIS_RAPAT_LIST.map((j) => (
                          <option key={j} value={j}>
                            {j}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Tanggal Pelaksanaan
                      </label>
                      <input
                        type="date"
                        value={minute.tanggal}
                        onChange={(e) => updateField('tanggal', e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Jam Mulai (WITA)
                      </label>
                      <input
                        type="time"
                        value={minute.waktuMulai}
                        onChange={(e) => updateField('waktuMulai', e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Jam Selesai (WITA)
                      </label>
                      <input
                        type="time"
                        value={minute.waktuSelesai}
                        onChange={(e) => updateField('waktuSelesai', e.target.value)}
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Tempat / Ruangan / Tautan Rapat
                      </label>
                      <input
                        type="text"
                        value={minute.tempat}
                        onChange={(e) => updateField('tempat', e.target.value)}
                        placeholder="Contoh: Ruang Rapat Rektorat Lt. 2, Kampus 1 UMB Palopo"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Nama Pimpinan Rapat
                      </label>
                      <input
                        type="text"
                        value={minute.pimpinanRapat}
                        onChange={(e) => updateField('pimpinanRapat', e.target.value)}
                        placeholder="Nama lengkap & gelar"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Jabatan Pimpinan Rapat
                      </label>
                      <input
                        type="text"
                        value={minute.jabatanPimpinan}
                        onChange={(e) => updateField('jabatanPimpinan', e.target.value)}
                        placeholder="Contoh: Rektor / Dekan Fakultas Kesehatan"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Nama Notulis
                      </label>
                      <input
                        type="text"
                        value={minute.notulis}
                        onChange={(e) => updateField('notulis', e.target.value)}
                        placeholder="Nama lengkap & gelar"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Jabatan Notulis
                      </label>
                      <input
                        type="text"
                        value={minute.jabatanNotulis}
                        onChange={(e) => updateField('jabatanNotulis', e.target.value)}
                        placeholder="Contoh: Sekretaris Prodi / Staf Tata Usaha"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: DAFTAR HADIR */}
              {activeTab === 'peserta' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-base font-semibold text-slate-900">Daftar Hadir Peserta</h2>
                      <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                        Total terdata: {minute.attendees.length} peserta ·{' '}
                        {minute.attendees.filter((a) => a.status === AttendanceStatus.HADIR).length} Hadir
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={addAttendee}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Peserta</span>
                    </button>
                  </div>

                  {minute.attendees.length === 0 ? (
                    <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
                      <p className="text-sm text-slate-500">Belum ada peserta rapat yang ditambahkan.</p>
                      <button
                        type="button"
                        onClick={addAttendee}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#0F294A] bg-slate-100 rounded-lg hover:bg-slate-200 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah Peserta Pertama</span>
                      </button>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
                      {minute.attendees.map((att, idx) => (
                        <div key={att.id} className="p-3.5 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                          <span className="sm:col-span-1 text-xs font-mono text-slate-400 tabular-nums">
                            {String(idx + 1).padStart(2, '0')}.
                          </span>
                          <input
                            type="text"
                            value={att.nama}
                            onChange={(e) => updateAttendee(att.id, { nama: e.target.value })}
                            placeholder="Nama lengkap & gelar"
                            className="sm:col-span-4 px-2.5 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                          />
                          <input
                            type="text"
                            value={att.jabatan}
                            onChange={(e) => updateAttendee(att.id, { jabatan: e.target.value })}
                            placeholder="Jabatan / Unit kerja"
                            className="sm:col-span-4 px-2.5 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                          />
                          <select
                            value={att.status}
                            onChange={(e) =>
                              updateAttendee(att.id, { status: e.target.value as AttendanceStatus })
                            }
                            aria-label="Status Kehadiran"
                            className="sm:col-span-2 px-2 py-1.5 text-xs font-medium border border-slate-200 rounded-md bg-white focus:outline-none focus:border-[#0F294A]"
                          >
                            {Object.values(AttendanceStatus).map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                          <div className="sm:col-span-1 flex justify-end">
                            <button
                              type="button"
                              onClick={() => removeAttendee(att.id)}
                              title="Hapus peserta"
                              className="p-1.5 text-slate-400 hover:text-rose-700 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: PEMBAHASAN AGENDA */}
              {activeTab === 'agenda' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-base font-semibold text-slate-900">
                        Agenda, Pembahasan &amp; Keputusan
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Catat pokok diskusi dan keputusan resmi untuk setiap mata acara rapat.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={addAgenda}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Agenda</span>
                    </button>
                  </div>

                  {minute.agendas.length === 0 ? (
                    <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
                      <p className="text-sm text-slate-500">Belum ada agenda pembahasan yang dicatat.</p>
                      <button
                        type="button"
                        onClick={addAgenda}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#0F294A] bg-slate-100 rounded-lg hover:bg-slate-200 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah Agenda Pertama</span>
                      </button>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
                      {minute.agendas.map((ag, idx) => (
                        <div key={ag.id} className="p-4 space-y-3">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold uppercase tracking-wider text-[#0F294A] tabular-nums">
                              Agenda {String(idx + 1).padStart(2, '0')}
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => moveAgenda(idx, -1)}
                                disabled={idx === 0}
                                title="Naikkan urutan"
                                className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => moveAgenda(idx, 1)}
                                disabled={idx === minute.agendas.length - 1}
                                title="Turunkan urutan"
                                className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => removeAgenda(ag.id)}
                                title="Hapus agenda"
                                className="p-1 text-slate-400 hover:text-rose-700 cursor-pointer ml-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-xs font-medium text-slate-600 mb-1">
                                Judul Agenda
                              </label>
                              <input
                                type="text"
                                value={ag.judul}
                                onChange={(e) => updateAgenda(ag.id, { judul: e.target.value })}
                                placeholder="Pokok bahasan agenda..."
                                className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-slate-600 mb-1">
                                Penyaji / Pembicara
                              </label>
                              <input
                                type="text"
                                value={ag.pembicara}
                                onChange={(e) => updateAgenda(ag.id, { pembicara: e.target.value })}
                                placeholder="Nama penyaji materi..."
                                className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">
                              Ringkasan Pembahasan / Diskusi
                            </label>
                            <textarea
                              rows={3}
                              value={ag.pembahasan}
                              onChange={(e) => updateAgenda(ag.id, { pembahasan: e.target.value })}
                              placeholder="Uraikan jalannya diskusi dan masukan peserta rapat..."
                              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-medium text-[#0F294A] mb-1">
                              Keputusan / Kesepakatan Rapat
                            </label>
                            <textarea
                              rows={2}
                              value={ag.keputusan}
                              onChange={(e) => updateAgenda(ag.id, { keputusan: e.target.value })}
                              placeholder="Tuliskan poin keputusan final yang disepakati..."
                              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: RENCANA TINDAK LANJUT */}
              {activeTab === 'tindaklanjut' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-base font-semibold text-slate-900">
                        Matriks Rencana Tindak Lanjut
                      </h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Daftar penugasan pasca-rapat yang otomatis muncul di Pelacak Tindak Lanjut.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={addActionItem}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Tindak Lanjut</span>
                    </button>
                  </div>

                  {minute.actionItems.length === 0 ? (
                    <div className="py-10 text-center border border-dashed border-slate-200 rounded-lg">
                      <p className="text-sm text-slate-500">Belum ada item tindak lanjut.</p>
                      <button
                        type="button"
                        onClick={addActionItem}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#0F294A] bg-slate-100 rounded-lg hover:bg-slate-200 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah Tugas Pertama</span>
                      </button>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
                      {minute.actionItems.map((act, idx) => (
                        <div key={act.id} className="p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-slate-600 tabular-nums">
                              Tugas #{idx + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => removeActionItem(act.id)}
                              title="Hapus tindak lanjut"
                              className="p-1 text-slate-400 hover:text-rose-700 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div>
                            <label className="block text-xs font-medium text-slate-600 mb-1">
                              Uraian Tugas / Tindak Lanjut
                            </label>
                            <input
                              type="text"
                              value={act.tugas}
                              onChange={(e) => updateActionItem(act.id, { tugas: e.target.value })}
                              placeholder="Contoh: Finalisasi dokumen borang LKPS..."
                              className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                            <div className="sm:col-span-2">
                              <label className="block text-xs font-medium text-slate-600 mb-1">
                                Penanggung Jawab (PIC)
                              </label>
                              <input
                                type="text"
                                value={act.penanggungJawab}
                                onChange={(e) =>
                                  updateActionItem(act.id, { penanggungJawab: e.target.value })
                                }
                                placeholder="Nama / Jabatan / Unit"
                                className="w-full px-3 py-1.5 text-sm border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-slate-600 mb-1">
                                Tenggat Waktu
                              </label>
                              <input
                                type="date"
                                value={act.tenggat}
                                onChange={(e) => updateActionItem(act.id, { tenggat: e.target.value })}
                                className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums border border-slate-200 rounded-md focus:outline-none focus:border-[#0F294A]"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-medium text-slate-600 mb-1">
                                Status
                              </label>
                              <select
                                value={act.status}
                                onChange={(e) =>
                                  updateActionItem(act.id, { status: e.target.value as ActionStatus })
                                }
                                className="w-full px-2.5 py-1.5 text-xs font-medium border border-slate-200 rounded-md bg-white focus:outline-none focus:border-[#0F294A]"
                              >
                                {Object.values(ActionStatus).map((st) => (
                                  <option key={st} value={st}>
                                    {st}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 5: PENGESAHAN */}
              {activeTab === 'pengesahan' && (
                <div className="space-y-5">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Penutup &amp; Pengesahan Dokumen
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Lengkapi catatan penutup serta NIDN/NIP untuk blok tanda tangan resmi.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Catatan Penutup Rapat
                      </label>
                      <textarea
                        rows={3}
                        value={minute.catatanPenutup}
                        onChange={(e) => updateField('catatanPenutup', e.target.value)}
                        placeholder="Contoh: Rapat ditutup pada pukul 12:00 WITA..."
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Kota Penetapan
                      </label>
                      <input
                        type="text"
                        value={minute.kotaPenetapan}
                        onChange={(e) => updateField('kotaPenetapan', e.target.value)}
                        placeholder="Palopo"
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        Status Pengesahan
                      </label>
                      <select
                        value={minute.status}
                        onChange={(e) => updateField('status', e.target.value as MeetingStatus)}
                        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-[#0F294A]"
                      >
                        <option value={MeetingStatus.DRAFT}>Draf (Masih Direvisi)</option>
                        <option value={MeetingStatus.FINAL}>Disahkan (Dokumen Final)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        NIDN / NIP Pimpinan Rapat
                      </label>
                      <input
                        type="text"
                        value={minute.nidnPimpinan}
                        onChange={(e) => updateField('nidnPimpinan', e.target.value)}
                        placeholder="Contoh: 0912047501"
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:border-[#0F294A]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1.5">
                        NIDN / NIP Notulis
                      </label>
                      <input
                        type="text"
                        value={minute.nidnNotulis}
                        onChange={(e) => updateField('nidnNotulis', e.target.value)}
                        placeholder="Contoh: 0921088902"
                        className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:border-[#0F294A]"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Live Document Preview Pane */}
        {(viewMode === 'preview' || viewMode === 'split') && (
          <div className={viewMode === 'split' ? 'xl:col-span-6' : 'block'}>
            <FormalDocumentPreview minute={minute} />
          </div>
        )}
      </div>
    </div>
  );
};
