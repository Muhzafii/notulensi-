import React, { useState } from 'react';
import { CheckCircle2, Clock, ExternalLink, Search, CircleDashed } from 'lucide-react';
import { ActionStatus, MeetingMinute } from '../types/notulen';
import { formatTanggalIndonesia } from '../utils/htmlExporter';

interface ActionItemsTrackerProps {
  minutes: MeetingMinute[];
  onUpdateActionStatus: (minuteId: string, actionId: string, newStatus: ActionStatus) => void;
  onOpenMinute: (minuteId: string) => void;
}

export const ActionItemsTracker: React.FC<ActionItemsTrackerProps> = ({
  minutes,
  onUpdateActionStatus,
  onOpenMinute,
}) => {
  const [statusFilter, setStatusFilter] = useState<'ALL' | ActionStatus>('ALL');
  const [query, setQuery] = useState('');

  const flattened = minutes.flatMap((m) =>
    m.actionItems.map((act) => ({
      ...act,
      minuteId: m.id,
      nomorSurat: m.nomorSurat,
      unitKerja: m.unitKerja,
      judulRapat: m.judul,
    }))
  );

  const filtered = flattened.filter((item) => {
    const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      item.tugas.toLowerCase().includes(q) ||
      item.penanggungJawab.toLowerCase().includes(q) ||
      item.unitKerja.toLowerCase().includes(q) ||
      item.nomorSurat.toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  const completedCount = flattened.filter((i) => i.status === ActionStatus.SELESAI).length;
  const inProgressCount = flattened.filter((i) => i.status === ActionStatus.BERJALAN).length;
  const pendingCount = flattened.filter((i) => i.status === ActionStatus.BELUM_MULAI).length;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-medium text-slate-500">
          Pemantauan Keputusan Rapat · Universitas Mega Buana Palopo
        </p>
        <h1 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1 text-balance">
          Pelacak Rencana Tindak Lanjut
        </h1>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 bg-white border border-slate-200 rounded-lg divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        <div className="p-4">
          <p className="text-xs font-medium text-slate-500">Total Tugas</p>
          <p className="text-xl font-semibold text-slate-900 mt-1 font-mono tabular-nums">
            {flattened.length}
          </p>
        </div>
        <div className="p-4">
          <p className="text-xs font-medium text-slate-500">Belum Dimulai</p>
          <p className="text-xl font-semibold text-slate-700 mt-1 font-mono tabular-nums">
            {pendingCount}
          </p>
        </div>
        <div className="p-4">
          <p className="text-xs font-medium text-slate-500">Sedang Berjalan</p>
          <p className="text-xl font-semibold text-amber-700 mt-1 font-mono tabular-nums">
            {inProgressCount}
          </p>
        </div>
        <div className="p-4">
          <p className="text-xs font-medium text-slate-500">Selesai</p>
          <p className="text-xl font-semibold text-emerald-700 mt-1 font-mono tabular-nums">
            {completedCount}
          </p>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari uraian tugas, PIC, atau unit kerja..."
            aria-label="Cari tindak lanjut"
            className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0F294A]/20 focus:border-[#0F294A]"
          />
        </div>

        <div className="inline-flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg overflow-x-auto">
          {(['ALL', ActionStatus.BELUM_MULAI, ActionStatus.BERJALAN, ActionStatus.SELESAI] as const).map(
            (st) => {
              const isActive = statusFilter === st;
              return (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st === 'ALL' ? 'Semua' : st}
                </button>
              );
            }
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-14 px-6 text-center text-sm text-slate-500">
            Tidak ada rencana tindak lanjut yang cocok dengan filter saat ini.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="px-4 py-3 text-left">Uraian Tindak Lanjut &amp; Rujukan Rapat</th>
                  <th className="px-4 py-3 text-left">Penanggung Jawab</th>
                  <th className="px-4 py-3 text-left whitespace-nowrap">Tenggat</th>
                  <th className="px-4 py-3 text-left whitespace-nowrap">Status</th>
                  <th className="px-4 py-3 text-right whitespace-nowrap">Dokumen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filtered.map((item) => (
                  <tr key={`${item.minuteId}-${item.id}`} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3.5 align-top max-w-md">
                      <p className="font-medium text-slate-900">{item.tugas || '-'}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        <span className="font-mono text-[#0F294A]">{item.nomorSurat}</span>
                        <span aria-hidden="true"> · </span>
                        <span>{item.unitKerja}</span>
                      </p>
                    </td>
                    <td className="px-4 py-3.5 align-top text-slate-700">
                      {item.penanggungJawab || '-'}
                    </td>
                    <td className="px-4 py-3.5 align-top text-xs font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {formatTanggalIndonesia(item.tenggat, false)}
                    </td>
                    <td className="px-4 py-3.5 align-top whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {item.status === ActionStatus.SELESAI && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        )}
                        {item.status === ActionStatus.BERJALAN && (
                          <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        )}
                        {item.status === ActionStatus.BELUM_MULAI && (
                          <CircleDashed className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        )}
                        <select
                          value={item.status}
                          onChange={(e) =>
                            onUpdateActionStatus(
                              item.minuteId,
                              item.id,
                              e.target.value as ActionStatus
                            )
                          }
                          aria-label={`Ubah status ${item.tugas}`}
                          className="text-xs font-medium bg-transparent border border-slate-200 rounded-md px-2 py-1 text-slate-800 focus:outline-none focus:border-[#0F294A] cursor-pointer"
                        >
                          {Object.values(ActionStatus).map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 align-top text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onOpenMinute(item.minuteId)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#0F294A] hover:underline cursor-pointer"
                      >
                        <span>Buka Notulen</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
