import React from 'react';

interface UniversityEmblemProps {
  className?: string;
}

export const UMB_EMBLEM_SVG_STRING = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" fill="none" role="img" aria-label="Lambang Universitas Mega Buana Palopo">
  <path d="M48 6L84 19V47C84 68.5 68.5 84.5 48 90C27.5 84.5 12 68.5 12 47V19L48 6Z" fill="#0F294A" stroke="#B48327" stroke-width="3.5"/>
  <path d="M48 13L77 23.5V47C77 64.5 64.5 77.5 48 82.5C31.5 77.5 19 64.5 19 47V23.5L48 13Z" fill="none" stroke="#E2B95B" stroke-width="1.2" opacity="0.85"/>
  <path d="M48 22L52.5 31.5L48 36L43.5 31.5L48 22Z" fill="#E2B95B"/>
  <path d="M29 41C35.5 38.5 42.5 39.5 48 43.5C53.5 39.5 60.5 38.5 67 41V60.5C60.5 58.2 53.5 59.2 48 63C42.5 59.2 35.5 58.2 29 60.5V41Z" fill="#FFFFFF" stroke="#E2B95B" stroke-width="1.5"/>
  <line x1="48" y1="43.5" x2="48" y2="63" stroke="#0F294A" stroke-width="1.8"/>
  <path d="M35 67.5C39.5 71 44 72.5 48 73.5C52 72.5 56.5 71 61 67.5" stroke="#E2B95B" stroke-width="2" stroke-linecap="round"/>
  <circle cx="48" cy="18" r="2.2" fill="#E2B95B"/>
</svg>`;

export const UniversityEmblem: React.FC<UniversityEmblemProps> = ({ className = 'w-14 h-14' }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 96 96"
      fill="none"
      className={className}
      role="img"
      aria-label="Lambang Universitas Mega Buana Palopo"
    >
      <path
        d="M48 6L84 19V47C84 68.5 68.5 84.5 48 90C27.5 84.5 12 68.5 12 47V19L48 6Z"
        fill="#0F294A"
        stroke="#B48327"
        strokeWidth="3.5"
      />
      <path
        d="M48 13L77 23.5V47C77 64.5 64.5 77.5 48 82.5C31.5 77.5 19 64.5 19 47V23.5L48 13Z"
        fill="none"
        stroke="#E2B95B"
        strokeWidth="1.2"
        opacity="0.85"
      />
      <path d="M48 22L52.5 31.5L48 36L43.5 31.5L48 22Z" fill="#E2B95B" />
      <path
        d="M29 41C35.5 38.5 42.5 39.5 48 43.5C53.5 39.5 60.5 38.5 67 41V60.5C60.5 58.2 53.5 59.2 48 63C42.5 59.2 35.5 58.2 29 60.5V41Z"
        fill="#FFFFFF"
        stroke="#E2B95B"
        strokeWidth="1.5"
      />
      <line x1="48" y1="43.5" x2="48" y2="63" stroke="#0F294A" strokeWidth="1.8" />
      <path
        d="M35 67.5C39.5 71 44 72.5 48 73.5C52 72.5 56.5 71 61 67.5"
        stroke="#E2B95B"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <circle cx="48" cy="18" r="2.2" fill="#E2B95B" />
    </svg>
  );
};
