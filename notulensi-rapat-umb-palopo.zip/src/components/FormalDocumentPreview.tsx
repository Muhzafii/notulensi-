import React from 'react';
import { AttendanceStatus, MeetingMinute } from '../types/notulen';
import { formatTanggalIndonesia } from '../utils/htmlExporter';
import { UniversityEmblem } from './UniversityEmblem';

interface FormalDocumentPreviewProps {
  minute: MeetingMinute;
}

export const FormalDocumentPreview: React.FC<FormalDocumentPreviewProps> = ({ minute }) => {
  const hadirCount = minute.attendees.filter((a) => a.status === AttendanceStatus.HADIR).length;
  const totalCount = minute.attendees.length;

  return (
    <article className="print-only-container mx-auto max-w-[820px] bg-white border border-slate-200 px-8 py-10 sm:px-12 sm:py-12 text-slate-900">
      {/* Kop Surat Resmi Universitas Mega Buana Palopo */}
      <header className="flex flex-col sm:flex-row items-center gap-4 pb-4 border-b-[3px] border-[#0F294A]">
        <UniversityEmblem className="w-16 h-16 sm:w-[72px] sm:h-[72px] shrink-0" />
        <div className="flex-1 text-center">
          <p className="text-[11px] uppercase tracking-[0.14em] text-slate-600 font-medium">
            Yayasan Mega Buana Palopo
          </p>
          <h1 className="font-serif text-xl sm:text-2xl font-bold uppercase tracking-wide text-[#0F294A] mt-0.5">
            Universitas Mega Buana Palopo
          </h1>
          <p className="text-xs sm:text-sm font-semibold text-slate-800 mt-0.5">
            {minute.unitKerja || 'Unit Kerja Universitas'}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            Jl. Andi Djemma No. 123, Kota Palopo, Sulawesi Selatan · Laman: umbpalopo.ac.id
          </p>
        </div>
      </header>
      <div className="border-t border-[#0F294A] mt-[3px] mb-6" />

      {/* Judul Dokumen */}
      <div className="text-center mb-6">
        <h2 className="font-serif text-lg sm:text-xl font-bold uppercase tracking-[0.08em] underline underline-offset-4 text-slate-900">
          Notulensi Rapat
        </h2>
        <p className="font-mono text-xs text-slate-600 mt-1.5 tabular-nums">
          Nomor: {minute.nomorSurat || '-'} · Status: {minute.status}
        </p>
      </div>

      {/* Identitas Rapat */}
      <div className="mb-7 overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <tbody className="divide-y divide-slate-100">
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 w-44 align-top">Perihal / Agenda</td>
              <td className="py-1.5 px-2 text-slate-500 w-4 align-top">:</td>
              <td className="py-1.5 font-semibold text-slate-900 align-top">{minute.judul || '-'}</td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Jenis Rapat</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 align-top">{minute.jenisRapat || '-'}</td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Hari / Tanggal</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 tabular-nums align-top">
                {formatTanggalIndonesia(minute.tanggal, true)}
              </td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Waktu</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 font-mono text-xs sm:text-sm tabular-nums align-top">
                {minute.waktuMulai || '--:--'} – {minute.waktuSelesai || '--:--'} WITA
              </td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Tempat / Media</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 align-top">{minute.tempat || '-'}</td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Pimpinan Rapat</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 align-top">
                {minute.pimpinanRapat || '-'}{' '}
                {minute.jabatanPimpinan ? `(${minute.jabatanPimpinan})` : ''}
              </td>
            </tr>
            <tr>
              <td className="py-1.5 pr-3 font-semibold text-slate-700 align-top">Notulis</td>
              <td className="py-1.5 px-2 text-slate-500 align-top">:</td>
              <td className="py-1.5 text-slate-800 align-top">
                {minute.notulis || '-'}{' '}
                {minute.jabatanNotulis ? `(${minute.jabatanNotulis})` : ''}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Bagian I: Daftar Hadir */}
      <section className="mb-7">
        <div className="flex items-baseline justify-between border-b border-slate-300 pb-1.5 mb-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0F294A]">
            I. Daftar Hadir Peserta
          </h3>
          <span className="text-xs text-slate-500 tabular-nums">
            {hadirCount} Hadir dari {totalCount} Terundang
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs sm:text-sm border-collapse border border-slate-300">
            <thead>
              <tr className="bg-slate-100 text-slate-800">
                <th className="border border-slate-300 px-2.5 py-2 text-center w-11 font-semibold">No</th>
                <th className="border border-slate-300 px-3 py-2 text-left font-semibold">Nama Peserta</th>
                <th className="border border-slate-300 px-3 py-2 text-left font-semibold">Jabatan / Unit</th>
                <th className="border border-slate-300 px-3 py-2 text-left w-32 font-semibold">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {minute.attendees.length === 0 ? (
                <tr>
                  <td colSpan={4} className="border border-slate-300 px-3 py-4 text-center text-slate-500">
                    Belum ada peserta yang dicatat.
                  </td>
                </tr>
              ) : (
                minute.attendees.map((att, idx) => (
                  <tr key={att.id} className="hover:bg-slate-50/70">
                    <td className="border border-slate-300 px-2.5 py-1.5 text-center tabular-nums text-slate-600">
                      {idx + 1}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 font-medium text-slate-900">
                      {att.nama || '-'}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700">
                      {att.jabatan || '-'}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-800">
                      {att.status}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Bagian II: Jalannya Rapat & Keputusan */}
      <section className="mb-7">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#0F294A] border-b border-slate-300 pb-1.5 mb-3">
          II. Jalannya Rapat, Pembahasan &amp; Keputusan
        </h3>

        {minute.agendas.length === 0 ? (
          <p className="text-sm text-slate-500 italic">Belum ada catatan agenda pembahasan.</p>
        ) : (
          <div className="divide-y divide-slate-200">
            {minute.agendas.map((ag, idx) => (
              <div key={ag.id} className="py-3.5 first:pt-1 last:pb-1 print-break-inside-avoid">
                <h4 className="text-sm font-bold text-slate-900">
                  {idx + 1}. {ag.judul || 'Agenda Tanpa Judul'}
                </h4>
                {ag.pembicara && (
                  <p className="text-xs text-slate-600 mt-1">
                    <span className="font-semibold text-slate-700">Penyaji / Pembicara:</span> {ag.pembicara}
                  </p>
                )}
                <div className="mt-2 space-y-2 text-sm text-slate-800 leading-relaxed">
                  <div>
                    <span className="font-semibold text-slate-900">Pokok Bahasan:</span>
                    <p className="mt-0.5 whitespace-pre-line text-slate-700">{ag.pembahasan || '-'}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-[#0F294A]">Keputusan / Kesepakatan:</span>
                    <p className="mt-0.5 whitespace-pre-line text-slate-900 font-medium">
                      {ag.keputusan || '-'}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Bagian III: Matriks Rencana Tindak Lanjut */}
      <section className="mb-7 print-break-inside-avoid">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#0F294A] border-b border-slate-300 pb-1.5 mb-3">
          III. Matriks Rencana Tindak Lanjut
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs sm:text-sm border-collapse border border-slate-300">
            <thead>
              <tr className="bg-slate-100 text-slate-800">
                <th className="border border-slate-300 px-2.5 py-2 text-center w-11 font-semibold">No</th>
                <th className="border border-slate-300 px-3 py-2 text-left font-semibold">Uraian Tindak Lanjut</th>
                <th className="border border-slate-300 px-3 py-2 text-left font-semibold">Penanggung Jawab</th>
                <th className="border border-slate-300 px-3 py-2 text-center w-32 font-semibold">Tenggat</th>
                <th className="border border-slate-300 px-3 py-2 text-left w-28 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {minute.actionItems.length === 0 ? (
                <tr>
                  <td colSpan={5} className="border border-slate-300 px-3 py-4 text-center text-slate-500">
                    Tidak ada item tindak lanjut.
                  </td>
                </tr>
              ) : (
                minute.actionItems.map((act, idx) => (
                  <tr key={act.id}>
                    <td className="border border-slate-300 px-2.5 py-1.5 text-center tabular-nums text-slate-600">
                      {idx + 1}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-900">
                      {act.tugas || '-'}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-700">
                      {act.penanggungJawab || '-'}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-center tabular-nums text-slate-700">
                      {formatTanggalIndonesia(act.tenggat, false)}
                    </td>
                    <td className="border border-slate-300 px-3 py-1.5 text-slate-800">
                      {act.status}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Bagian IV: Penutup & Pengesahan */}
      <section className="print-break-inside-avoid">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#0F294A] border-b border-slate-300 pb-1.5 mb-3">
          IV. Penutup &amp; Pengesahan
        </h3>
        <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">
          {minute.catatanPenutup ||
            'Demikian notulensi rapat ini disusun dengan sebenar-benarnya untuk dipergunakan sebagaimana mestinya.'}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mt-10 text-sm">
          <div>
            <p className="text-slate-700">Mengetahui / Pimpinan Rapat,</p>
            <p className="text-slate-800 font-medium mt-0.5">{minute.jabatanPimpinan || 'Pimpinan Rapat'}</p>
            <div className="h-16" />
            <p className="font-bold underline underline-offset-4 text-slate-900">
              {minute.pimpinanRapat || '........................................'}
            </p>
            {minute.nidnPimpinan && (
              <p className="text-xs font-mono text-slate-600 mt-1 tabular-nums">
                NIDN/NIP. {minute.nidnPimpinan}
              </p>
            )}
          </div>

          <div>
            <p className="text-slate-700 tabular-nums">
              {minute.kotaPenetapan || 'Palopo'}, {formatTanggalIndonesia(minute.tanggal, false)}
            </p>
            <p className="text-slate-800 font-medium mt-0.5">Notulis Rapat,</p>
            <div className="h-16" />
            <p className="font-bold underline underline-offset-4 text-slate-900">
              {minute.notulis || '........................................'}
            </p>
            {minute.nidnNotulis && (
              <p className="text-xs font-mono text-slate-600 mt-1 tabular-nums">
                NIDN/NIP. {minute.nidnNotulis}
              </p>
            )}
          </div>
        </div>
      </section>
    </article>
  );
};
