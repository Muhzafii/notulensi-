import {
  ActionPriority,
  ActionStatus,
  AttendanceStatus,
  MeetingMinute,
  MeetingStatus,
} from '../types/notulen';

export const INITIAL_MINUTES: MeetingMinute[] = [
  {
    id: 'umb-not-001',
    nomorSurat: '042/NOT-SENAT/UMB-PLP/XI/2026',
    judul: 'Rapat Evaluasi Kesiapan Akreditasi Program Studi & Penguatan Mutu Akademik Semester Gasal 2026/2027',
    unitKerja: 'Rektorat & Senat Akademik',
    jenisRapat: 'Rapat Senat Akademik',
    tanggal: '2026-11-20',
    waktuMulai: '09:00',
    waktuSelesai: '12:15',
    tempat: 'Ruang Rapat Senat Lt. 3, Kampus 1 Universitas Mega Buana Palopo',
    pimpinanRapat: 'Prof. Dr. Hj. Nilawati Uly, S.Si., Apt., M.Kes.',
    jabatanPimpinan: 'Rektor Universitas Mega Buana Palopo',
    nidnPimpinan: '0912047501',
    notulis: 'Andi Muh. Akbar, S.Kom., M.M.',
    jabatanNotulis: 'Kepala Bagian Tata Usaha & Kesekretariatan Rektorat',
    nidnNotulis: '0921088902',
    status: MeetingStatus.FINAL,
    attendees: [
      {
        id: 'att-1',
        nama: 'Prof. Dr. Hj. Nilawati Uly, S.Si., Apt., M.Kes.',
        jabatan: 'Rektor',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-2',
        nama: 'Dr. H. Abdul Rahman, S.E., M.Si.',
        jabatan: 'Wakil Rektor I Bidang Akademik',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-3',
        nama: 'Ns. Yuniar, S.Kep., M.Kes.',
        jabatan: 'Dekan Fakultas Kesehatan',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-4',
        nama: 'Dr. Rahmawati, S.E., M.Ak.',
        jabatan: 'Dekan Fakultas Ekonomi & Bisnis',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-5',
        nama: 'Ir. Hendra Wijaya, S.T., M.T.',
        jabatan: 'Dekan Fakultas Sains & Teknologi',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-6',
        nama: 'Dr. Sukmawati, M.Keb.',
        jabatan: 'Ketua Lembaga Penjaminan Mutu (LPM)',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-7',
        nama: 'Muhammad Yusuf, S.Kom., M.Cs.',
        jabatan: 'Kepala Unit Sistem Informasi Akademik',
        status: AttendanceStatus.IZIN,
      },
    ],
    agendas: [
      {
        id: 'ag-1',
        judul: 'Laporan Kemajuan Penyusunan Borang LED & LKPS Program Studi',
        pembicara: 'Dr. Sukmawati, M.Keb. (Ketua LPM)',
        pembahasan:
          'LPM memaparkan progres pengisian Laporan Evaluasi Diri (LED) dan Laporan Kinerja Program Studi (LKPS) untuk tiga program studi yang akan mengajukan reakreditasi LAM-PTKes dan LAMEMBA pada triwulan pertama 2027. Kelengkapan bukti pelacakan alumni (tracer study) dan luaran penelitian dosen masih perlu dilengkapi pada dua program studi.',
        keputusan:
          'Seluruh Dekan dan Ketua Program Studi wajib menyerahkan draf final LKPS beserta lampiran bukti dukung ke LPM paling lambat 10 Desember 2026.',
      },
      {
        id: 'ag-2',
        judul: 'Optimalisasi Pelaporan PDDikti & Integrasi SIAKAD Semester Gasal',
        pembicara: 'Dr. H. Abdul Rahman, S.E., M.Si. (Wakil Rektor I)',
        pembahasan:
          'Evaluasi ketepatan waktu input nilai, KRS, dan validasi data mahasiswa aktif pada sistem informasi akademik. Ditemukan beberapa mata kuliah praktik yang belum melampirkan RPS berbasis Outcome-Based Education (OBE) secara digital.',
        keputusan:
          'Biro Administrasi Akademik bersama Unit SIAKAD melaksanakan pendampingan pengunggahan RPS OBE bagi seluruh dosen pengampu pada minggu pertama Desember 2026.',
      },
      {
        id: 'ag-3',
        judul: 'Penguatan Publikasi Ilmiah & Hibah Penelitian Internal Tahun 2027',
        pembicara: 'Prof. Dr. Hj. Nilawati Uly, S.Si., Apt., M.Kes. (Rektor)',
        pembahasan:
          'Rektor menekankan pentingnya peningkatan rasio publikasi dosen pada jurnal bereputasi nasional (SINTA 1–3) dan internasional terindeks, serta kolaborasi penelitian lintas fakultas yang melibatkan mahasiswa tingkat akhir.',
        keputusan:
          'LPPM menyusun skema insentif publikasi dan membuka pendaftaran proposal hibah penelitian internal tahun anggaran 2027 mulai Januari 2027.',
      },
    ],
    actionItems: [
      {
        id: 'act-1',
        tugas: 'Finalisasi draf LKPS & verifikasi data tracer study 2024–2026',
        penanggungJawab: 'Ketua LPM & Para Dekan Fakultas',
        tenggat: '2026-12-10',
        prioritas: ActionPriority.TINGGI,
        status: ActionStatus.BERJALAN,
      },
      {
        id: 'act-2',
        tugas: 'Klinik unggah RPS berbasis OBE ke portal SIAKAD UMB Palopo',
        penanggungJawab: 'Biro Akademik & Unit SIAKAD',
        tenggat: '2026-12-05',
        prioritas: ActionPriority.SEDANG,
        status: ActionStatus.BELUM_MULAI,
      },
      {
        id: 'act-3',
        tugas: 'Penerbitan pedoman hibah penelitian internal & insentif publikasi 2027',
        penanggungJawab: 'Ketua LPPM',
        tenggat: '2026-12-20',
        prioritas: ActionPriority.NORMAL,
        status: ActionStatus.SELESAI,
      },
    ],
    catatanPenutup:
      'Rapat ditutup oleh Rektor Universitas Mega Buana Palopo pada pukul 12:15 WITA dengan harapan seluruh unit kerja menindaklanjuti keputusan sesuai batas waktu yang telah disepakati.',
    kotaPenetapan: 'Palopo',
    updatedAt: '2026-11-20T13:10:00Z',
  },
  {
    id: 'umb-not-002',
    nomorSurat: '039/NOT-FKES/UMB-PLP/XI/2026',
    judul: 'Rapat Koordinasi Pelaksanaan Praktik Klinik & Uji Kompetensi Mahasiswa Kebidanan dan Keperawatan',
    unitKerja: 'Fakultas Kesehatan',
    jenisRapat: 'Rapat Koordinasi Unit',
    tanggal: '2026-11-18',
    waktuMulai: '13:30',
    waktuSelesai: '15:45',
    tempat: 'Aula Fakultas Kesehatan Lt. 2, UMB Palopo',
    pimpinanRapat: 'Ns. Yuniar, S.Kep., M.Kes.',
    jabatanPimpinan: 'Dekan Fakultas Kesehatan',
    nidnPimpinan: '0904068103',
    notulis: 'Bdn. Nurul Hidayah, S.ST., M.Keb.',
    jabatanNotulis: 'Sekretaris Program Studi Kebidanan',
    nidnNotulis: '0917099001',
    status: MeetingStatus.FINAL,
    attendees: [
      {
        id: 'att-201',
        nama: 'Ns. Yuniar, S.Kep., M.Kes.',
        jabatan: 'Dekan Fakultas Kesehatan',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-202',
        nama: 'Ns. Herman, S.Kep., M.Kep.',
        jabatan: 'Ketua Prodi Ilmu Keperawatan & Ners',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-203',
        nama: 'Bdn. Nurul Hidayah, S.ST., M.Keb.',
        jabatan: 'Sekretaris Prodi Kebidanan',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-204',
        nama: 'apt. Rizky Amalia, S.Farm., M.Farm.',
        jabatan: 'Koordinator Laboratorium Terpadu',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-205',
        nama: 'Sri Wahyuni, S.KM., M.Kes.',
        jabatan: 'Ketua Prodi Kesehatan Masyarakat',
        status: AttendanceStatus.HADIR,
      },
    ],
    agendas: [
      {
        id: 'ag-201',
        judul: 'Penempatan Mahasiswa Praktik Klinik di RSUD Sawerigading & Puskesmas Mitra',
        pembicara: 'Ns. Herman, S.Kep., M.Kep.',
        pembahasan:
          'Pembagian kelompok praktik klinik semester gasal untuk 145 mahasiswa Keperawatan dan Kebidanan di wilayah Kota Palopo, Kabupaten Luwu, dan Luwu Utara beserta penjadwalan pembimbing klinik (CI) dan dosen pembimbing akademik.',
        keputusan:
          'Surat pengantar resmi dan daftar nama kelompok mahasiswa dikirimkan ke rumah sakit dan dinas kesehatan mitra paling lambat 25 November 2026.',
      },
      {
        id: 'ag-202',
        judul: 'Simulasi Try Out Uji Kompetensi Nasional (UKOM) Mahasiswa Tingkat Akhir',
        pembicara: 'Bdn. Nurul Hidayah, S.ST., M.Keb.',
        pembahasan:
          'Peningkatan kesiapan kelulusan first-taker UKOM melalui pelaksanaan try out berbasis komputer (CBT) di laboratorium komputer Fakultas Kesehatan sebanyak tiga gelombang sebelum ujian nasional.',
        keputusan:
          'Gelombang I Try Out UKOM dijadwalkan pada 12 Desember 2026 dengan wajib kehadiran 100% bagi mahasiswa tingkat akhir.',
      },
    ],
    actionItems: [
      {
        id: 'act-201',
        tugas: 'Penerbitan surat tugas pembimbing klinik & pengantar lahan praktik RSUD Sawerigading',
        penanggungJawab: 'Tata Usaha Fakultas Kesehatan',
        tenggat: '2026-11-28',
        prioritas: ActionPriority.TINGGI,
        status: ActionStatus.SELESAI,
      },
      {
        id: 'act-202',
        tugas: 'Persiapan server CBT & bank soal Try Out UKOM Gelombang I',
        penanggungJawab: 'Koordinator Lab & Tim UKOM Prodi',
        tenggat: '2026-12-08',
        prioritas: ActionPriority.TINGGI,
        status: ActionStatus.BERJALAN,
      },
    ],
    catatanPenutup:
      'Seluruh ketua program studi diminta melaporkan hasil pembekalan praktik klinik mahasiswa kepada Dekan sebelum tanggal keberangkatan ke lahan praktik.',
    kotaPenetapan: 'Palopo',
    updatedAt: '2026-11-18T16:10:00Z',
  },
  {
    id: 'umb-not-003',
    nomorSurat: '045/NOT-LPPM/UMB-PLP/XI/2026',
    judul: 'Penyusunan Roadmap Penelitian Terapan & Pengabdian Masyarakat Berbasis Potensi Luwu Raya',
    unitKerja: 'LPPM',
    jenisRapat: 'Rapat Koordinasi Unit',
    tanggal: '2026-11-24',
    waktuMulai: '10:00',
    waktuSelesai: '12:00',
    tempat: 'Ruang Rapat LPPM & Zoom Meeting Hybrid',
    pimpinanRapat: 'Dr. Arifuddin, S.E., M.M.',
    jabatanPimpinan: 'Ketua LPPM Universitas Mega Buana Palopo',
    nidnPimpinan: '0915038404',
    notulis: 'Fitriani, S.Pd., M.Pd.',
    jabatanNotulis: 'Staf Ahli Bidang Pengabdian Masyarakat LPPM',
    nidnNotulis: '0928119201',
    status: MeetingStatus.DRAFT,
    attendees: [
      {
        id: 'att-301',
        nama: 'Dr. Arifuddin, S.E., M.M.',
        jabatan: 'Ketua LPPM',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-302',
        nama: 'Fitriani, S.Pd., M.Pd.',
        jabatan: 'Sekretaris & Staf Ahli LPPM',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-303',
        nama: 'Dr. Rahmawati, S.E., M.Ak.',
        jabatan: 'Dekan Fakultas Ekonomi & Bisnis',
        status: AttendanceStatus.HADIR,
      },
      {
        id: 'att-304',
        nama: 'Ir. Hendra Wijaya, S.T., M.T.',
        jabatan: 'Dekan Fakultas Sains & Teknologi',
        status: AttendanceStatus.HADIR,
      },
    ],
    agendas: [
      {
        id: 'ag-301',
        judul: 'Pemetaan Klaster Riset Unggulan Daerah Luwu Raya',
        pembicara: 'Dr. Arifuddin, S.E., M.M.',
        pembahasan:
          'Integrasi tema penelitian dosen lintas fakultas pada tiga klaster utama: kesehatan masyarakat pesisir, pemberdayaan UMKM & ekonomi syariah, serta teknologi tepat guna sektor agroindustri dan perikanan di wilayah Palopo dan Luwu Raya.',
        keputusan:
          'Masing-masing fakultas mengirimkan dua perwakilan tim perumus klaster riset untuk menyusun dokumen final roadmap 2027–2031.',
      },
    ],
    actionItems: [
      {
        id: 'act-301',
        tugas: 'Mengumpulkan daftar nama tim perumus klaster riset dari tiap fakultas',
        penanggungJawab: 'Sekretaris LPPM',
        tenggat: '2026-12-04',
        prioritas: ActionPriority.SEDANG,
        status: ActionStatus.BELUM_MULAI,
      },
    ],
    catatanPenutup:
      'Draf notulen ini masih menunggu masukan tambahan dari Fakultas Sains & Teknologi terkait indikator luaran prototipe teknologi tepat guna.',
    kotaPenetapan: 'Palopo',
    updatedAt: '2026-11-24T12:30:00Z',
  },
];
