import { UMB_EMBLEM_SVG_STRING } from '../components/UniversityEmblem';
import { AttendanceStatus, MeetingMinute } from '../types/notulen';

const HARI_ID = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const BULAN_ID = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

export function formatTanggalIndonesia(isoDate: string, includeDay = true): string {
  if (!isoDate) return '-';
  const parts = isoDate.split('-').map(Number);
  if (parts.length !== 3 || parts.some(isNaN)) return isoDate;
  const [year, month, day] = parts;
  const dateObj = new Date(year, month - 1, day);
  const namaHari = HARI_ID[dateObj.getDay()] ?? '';
  const namaBulan = BULAN_ID[month - 1] ?? '';
  if (includeDay) {
    return `${namaHari}, ${day} ${namaBulan} ${year}`;
  }
  return `${day} ${namaBulan} ${year}`;
}

function escapeHtml(raw: string): string {
  return (raw || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function generateStandaloneHtml(minute: MeetingMinute): string {
  const hadirCount = minute.attendees.filter((a) => a.status === AttendanceStatus.HADIR).length;
  const totalCount = minute.attendees.length;

  const attendeesRows = minute.attendees
    .map(
      (att, idx) => `
      <tr>
        <td class="num">${idx + 1}</td>
        <td>${escapeHtml(att.nama)}</td>
        <td>${escapeHtml(att.jabatan)}</td>
        <td>${escapeHtml(att.status)}</td>
      </tr>`
    )
    .join('');

  const agendaBlocks = minute.agendas
    .map(
      (ag, idx) => `
      <div class="agenda-item">
        <h4>${idx + 1}. ${escapeHtml(ag.judul)}</h4>
        <p class="speaker"><strong>Penyaji / Pembicara:</strong> ${escapeHtml(ag.pembicara || '-')}</p>
        <p class="prose"><strong>Pokok Bahasan:</strong><br/>${escapeHtml(ag.pembahasan).replace(/\n/g, '<br/>')}</p>
        <p class="decision"><strong>Keputusan / Kesepakatan:</strong><br/>${escapeHtml(ag.keputusan).replace(/\n/g, '<br/>')}</p>
      </div>`
    )
    .join('');

  const actionRows = minute.actionItems
    .map(
      (act, idx) => `
      <tr>
        <td class="num">${idx + 1}</td>
        <td>${escapeHtml(act.tugas)}</td>
        <td>${escapeHtml(act.penanggungJawab)}</td>
        <td class="num">${escapeHtml(formatTanggalIndonesia(act.tenggat, false))}</td>
        <td>${escapeHtml(act.prioritas)}</td>
        <td>${escapeHtml(act.status)}</td>
      </tr>`
    )
    .join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Notulensi Rapat - ${escapeHtml(minute.nomorSurat || minute.judul)}</title>
  <style>
    @page { size: A4 portrait; margin: 16mm 18mm; }
    * { box-sizing: border-box; }
    body {
      font-family: "Times New Roman", Georgia, serif;
      color: #111827;
      background: #f3f4f6;
      margin: 0;
      padding: 24px 16px;
      line-height: 1.55;
      font-size: 11.5pt;
    }
    .sheet {
      max-width: 820px;
      margin: 0 auto;
      background: #ffffff;
      padding: 40px 48px;
      border: 1px solid #d1d5db;
    }
    .kop {
      display: flex;
      align-items: center;
      gap: 18px;
      padding-bottom: 14px;
      border-bottom: 3px solid #0F294A;
      margin-bottom: 3px;
    }
    .kop-double {
      border-top: 1px solid #0F294A;
      margin-bottom: 22px;
    }
    .kop-logo { width: 72px; height: 72px; flex-shrink: 0; }
    .kop-text { flex: 1; text-align: center; }
    .kop-yayasan { font-size: 11pt; letter-spacing: 0.08em; text-transform: uppercase; color: #374151; margin: 0; }
    .kop-univ { font-size: 16pt; font-weight: 700; letter-spacing: 0.03em; text-transform: uppercase; color: #0F294A; margin: 2px 0; }
    .kop-unit { font-size: 11pt; font-weight: 600; color: #1f2937; margin: 2px 0; }
    .kop-alamat { font-size: 9.5pt; color: #4b5563; margin: 2px 0 0; }
    .doc-title { text-align: center; margin-bottom: 20px; }
    .doc-title h1 { font-size: 14pt; text-transform: uppercase; letter-spacing: 0.06em; margin: 0 0 4px; text-decoration: underline; }
    .doc-title p { font-size: 10.5pt; margin: 0; color: #374151; font-family: "Courier New", monospace; }
    .meta-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 10.5pt; }
    .meta-table td { padding: 4px 6px; vertical-align: top; }
    .meta-table td.label { width: 170px; font-weight: 600; color: #1f2937; }
    .meta-table td.sep { width: 14px; text-align: center; }
    h3.section-heading {
      font-size: 11.5pt;
      text-transform: uppercase;
      letter-spacing: 0.03em;
      border-bottom: 1px solid #d1d5db;
      padding-bottom: 4px;
      margin: 22px 0 10px;
      color: #0F294A;
    }
    table.data-table { width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 10pt; }
    table.data-table th, table.data-table td { border: 1px solid #9ca3af; padding: 6px 8px; text-align: left; vertical-align: top; }
    table.data-table th { background: #f3f4f6; font-weight: 700; color: #111827; }
    table.data-table td.num, table.data-table th.num { text-align: center; font-variant-numeric: tabular-nums; }
    .agenda-item { margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px dashed #e5e7eb; }
    .agenda-item h4 { margin: 0 0 6px; font-size: 11pt; color: #111827; }
    .agenda-item p { margin: 4px 0; text-align: justify; }
    .agenda-item .speaker { font-size: 10pt; color: #374151; }
    .closing { margin-top: 14px; text-align: justify; }
    .signatures {
      display: flex;
      justify-content: space-between;
      margin-top: 34px;
      gap: 32px;
      page-break-inside: avoid;
    }
    .sig-box { width: 45%; font-size: 10.5pt; }
    .sig-space { height: 68px; }
    .sig-name { font-weight: 700; text-decoration: underline; margin: 0; }
    .sig-nidn { font-size: 9.5pt; color: #374151; margin: 2px 0 0; }
    @media print {
      body { background: #ffffff; padding: 0; }
      .sheet { border: none; padding: 0; max-width: none; }
    }
  </style>
</head>
<body>
  <article class="sheet">
    <header class="kop">
      <div class="kop-logo">${UMB_EMBLEM_SVG_STRING}</div>
      <div class="kop-text">
        <p class="kop-yayasan">Yayasan Mega Buana Palopo</p>
        <h2 class="kop-univ">Universitas Mega Buana Palopo</h2>
        <p class="kop-unit">${escapeHtml(minute.unitKerja)}</p>
        <p class="kop-alamat">Jl. Andi Djemma No. 123, Kota Palopo, Sulawesi Selatan · Laman: umbpalopo.ac.id</p>
      </div>
    </header>
    <div class="kop-double"></div>

    <div class="doc-title">
      <h1>Notulensi Rapat</h1>
      <p>Nomor: ${escapeHtml(minute.nomorSurat || '-')} &middot; Status: ${escapeHtml(minute.status)}</p>
    </div>

    <table class="meta-table">
      <tr><td class="label">Perihal / Agenda Utama</td><td class="sep">:</td><td><strong>${escapeHtml(minute.judul)}</strong></td></tr>
      <tr><td class="label">Jenis Rapat</td><td class="sep">:</td><td>${escapeHtml(minute.jenisRapat)}</td></tr>
      <tr><td class="label">Hari / Tanggal</td><td class="sep">:</td><td>${escapeHtml(formatTanggalIndonesia(minute.tanggal, true))}</td></tr>
      <tr><td class="label">Waktu</td><td class="sep">:</td><td>${escapeHtml(minute.waktuMulai)} – ${escapeHtml(minute.waktuSelesai)} WITA</td></tr>
      <tr><td class="label">Tempat / Media</td><td class="sep">:</td><td>${escapeHtml(minute.tempat)}</td></tr>
      <tr><td class="label">Pimpinan Rapat</td><td class="sep">:</td><td>${escapeHtml(minute.pimpinanRapat)} (${escapeHtml(minute.jabatanPimpinan)})</td></tr>
      <tr><td class="label">Notulis</td><td class="sep">:</td><td>${escapeHtml(minute.notulis)} (${escapeHtml(minute.jabatanNotulis)})</td></tr>
    </table>

    <h3 class="section-heading">I. Daftar Hadir Peserta (${hadirCount} Hadir dari ${totalCount} Terundang)</h3>
    <table class="data-table">
      <thead>
        <tr>
          <th class="num" style="width:42px;">No</th>
          <th>Nama Peserta</th>
          <th>Jabatan / Unit Kerja</th>
          <th style="width:130px;">Keterangan</th>
        </tr>
      </thead>
      <tbody>
        ${attendeesRows || '<tr><td colspan="4" class="num">Belum ada data peserta.</td></tr>'}
      </tbody>
    </table>

    <h3 class="section-heading">II. Jalannya Rapat, Pembahasan &amp; Keputusan</h3>
    ${agendaBlocks || '<p>Belum ada catatan agenda rapat.</p>'}

    <h3 class="section-heading">III. Matriks Rencana Tindak Lanjut</h3>
    <table class="data-table">
      <thead>
        <tr>
          <th class="num" style="width:42px;">No</th>
          <th>Uraian Tindak Lanjut</th>
          <th>Penanggung Jawab</th>
          <th class="num" style="width:125px;">Tenggat</th>
          <th style="width:85px;">Prioritas</th>
          <th style="width:115px;">Status</th>
        </tr>
      </thead>
      <tbody>
        ${actionRows || '<tr><td colspan="6" class="num">Tidak ada item tindak lanjut.</td></tr>'}
      </tbody>
    </table>

    <h3 class="section-heading">IV. Penutup</h3>
    <p class="closing">${escapeHtml(minute.catatanPenutup || 'Demikian notulensi rapat ini dibuat untuk dipergunakan sebagaimana mestinya.')}</p>

    <div class="signatures">
      <div class="sig-box">
        <p style="margin:0;">Mengetahui / Pimpinan Rapat,</p>
        <p style="margin:2px 0 0;">${escapeHtml(minute.jabatanPimpinan)}</p>
        <div class="sig-space"></div>
        <p class="sig-name">${escapeHtml(minute.pimpinanRapat)}</p>
        ${minute.nidnPimpinan ? `<p class="sig-nidn">NIDN/NIP. ${escapeHtml(minute.nidnPimpinan)}</p>` : ''}
      </div>
      <div class="sig-box">
        <p style="margin:0;">${escapeHtml(minute.kotaPenetapan || 'Palopo')}, ${escapeHtml(formatTanggalIndonesia(minute.tanggal, false))}</p>
        <p style="margin:2px 0 0;">Notulis Rapat,</p>
        <div class="sig-space"></div>
        <p class="sig-name">${escapeHtml(minute.notulis)}</p>
        ${minute.nidnNotulis ? `<p class="sig-nidn">NIDN/NIP. ${escapeHtml(minute.nidnNotulis)}</p>` : ''}
      </div>
    </div>
  </article>
</body>
</html>`;
}

export function downloadHtmlFile(minute: MeetingMinute): void {
  const htmlContent = generateStandaloneHtml(minute);
  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const safeFileBase = (minute.nomorSurat || minute.judul || 'notulen')
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Notulen_UMB_Palopo_${safeFileBase}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
