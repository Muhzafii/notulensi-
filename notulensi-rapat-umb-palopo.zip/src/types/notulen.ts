export enum MeetingStatus {
  DRAFT = 'Draf',
  FINAL = 'Disahkan',
}

export enum AttendanceStatus {
  HADIR = 'Hadir',
  IZIN = 'Izin',
  SAKIT = 'Sakit',
  TIDAK_HADIR = 'Tanpa Keterangan',
}

export enum ActionStatus {
  BELUM_MULAI = 'Belum Dimulai',
  BERJALAN = 'Sedang Berjalan',
  SELESAI = 'Selesai',
}

export enum ActionPriority {
  TINGGI = 'Tinggi',
  SEDANG = 'Sedang',
  NORMAL = 'Normal',
}

export const UNIT_KERJA_LIST = [
  'Rektorat & Senat Akademik',
  'Fakultas Kesehatan',
  'Fakultas Ekonomi & Bisnis',
  'Fakultas Sains & Teknologi',
  'Program Pascasarjana',
  'Lembaga Penjaminan Mutu (LPM)',
  'LPPM',
  'Biro Administrasi Akademik & Kemahasiswaan',
] as const;

export const JENIS_RAPAT_LIST = [
  'Rapat Pimpinan',
  'Rapat Senat Akademik',
  'Rapat Koordinasi Unit',
  'Rapat Evaluasi Mutu',
  'Rapat Penyusunan Kurikulum',
  'Rapat Panitia Kegiatan',
] as const;

export interface Attendee {
  id: string;
  nama: string;
  jabatan: string;
  status: AttendanceStatus;
}

export interface AgendaItem {
  id: string;
  judul: string;
  pembicara: string;
  pembahasan: string;
  keputusan: string;
}

export interface ActionItem {
  id: string;
  tugas: string;
  penanggungJawab: string;
  tenggat: string;
  prioritas: ActionPriority;
  status: ActionStatus;
}

export interface MeetingMinute {
  id: string;
  nomorSurat: string;
  judul: string;
  unitKerja: string;
  jenisRapat: string;
  tanggal: string; // YYYY-MM-DD
  waktuMulai: string; // HH:mm
  waktuSelesai: string; // HH:mm
  tempat: string;
  pimpinanRapat: string;
  jabatanPimpinan: string;
  nidnPimpinan: string;
  notulis: string;
  jabatanNotulis: string;
  nidnNotulis: string;
  status: MeetingStatus;
  attendees: Attendee[];
  agendas: AgendaItem[];
  actionItems: ActionItem[];
  catatanPenutup: string;
  kotaPenetapan: string;
  updatedAt: string;
}
