/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckSquare,
  FilePlus2,
  FileText,
  Menu,
  RotateCcw,
  X,
} from 'lucide-react';
import { ActionItemsTracker } from './components/ActionItemsTracker';
import { MinutesEditor } from './components/MinutesEditor';
import { MinutesListView } from './components/MinutesListView';
import { UniversityEmblem } from './components/UniversityEmblem';
import { INITIAL_MINUTES } from './data/initialMinutes';
import {
  ActionStatus,
  JENIS_RAPAT_LIST,
  MeetingMinute,
  MeetingStatus,
  UNIT_KERJA_LIST,
} from './types/notulen';
import { downloadHtmlFile } from './utils/htmlExporter';

const STORAGE_KEY = 'umb_palopo_notulensi_v1';

function loadMinutesFromStorage(): MeetingMinute[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_MINUTES;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed;
    return INITIAL_MINUTES;
  } catch {
    return INITIAL_MINUTES;
  }
}

export default function App() {
  const [minutes, setMinutes] = useState<MeetingMinute[]>(loadMinutesFromStorage);
  const [activeNav, setActiveNav] = useState<'list' | 'actions'>('list');
  const [selectedUnit, setSelectedUnit] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | MeetingStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editorInitialMode, setEditorInitialMode] = useState<'edit' | 'preview'>('edit');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<MeetingMinute | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(minutes));
    } catch {
      // Ignore storage quota errors silently
    }
  }, [minutes]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const activeMinute = useMemo(
    () => minutes.find((m) => m.id === editingId) || null,
    [minutes, editingId]
  );

  const filteredMinutes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return minutes
      .filter((m) => {
        const matchesUnit = selectedUnit === 'ALL' || m.unitKerja === selectedUnit;
        const matchesStatus = statusFilter === 'ALL' || m.status === statusFilter;
        const matchesQuery =
          !q ||
          m.judul.toLowerCase().includes(q) ||
          m.nomorSurat.toLowerCase().includes(q) ||
          m.pimpinanRapat.toLowerCase().includes(q) ||
          m.notulis.toLowerCase().includes(q) ||
          m.tempat.toLowerCase().includes(q);
        return matchesUnit && matchesStatus && matchesQuery;
      })
      .sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  }, [minutes, selectedUnit, statusFilter, searchQuery]);

  const handleCreateNew = () => {
    const today = new Date().toISOString().slice(0, 10);
    const defaultUnit = selectedUnit === 'ALL' ? UNIT_KERJA_LIST[0] : selectedUnit;
    const seq = String(minutes.length + 46).padStart(3, '0');
    const newMinute: MeetingMinute = {
      id: `umb-not-${Date.now()}`,
      nomorSurat: `${seq}/NOT-UMB/UMB-PLP/XI/${today.slice(0, 4)}`,
      judul: 'Rapat Koordinasi Unit Kerja',
      unitKerja: defaultUnit,
      jenisRapat: JENIS_RAPAT_LIST[2],
      tanggal: today,
      waktuMulai: '09:00',
      waktuSelesai: '11:00',
      tempat: 'Ruang Rapat Kampus 1 Universitas Mega Buana Palopo',
      pimpinanRapat: '',
      jabatanPimpinan: '',
      nidnPimpinan: '',
      notulis: '',
      jabatanNotulis: '',
      nidnNotulis: '',
      status: MeetingStatus.DRAFT,
      attendees: [],
      agendas: [
        {
          id: `ag-${Date.now()}`,
          judul: 'Pembukaan & Pembahasan Utama',
          pembicara: '',
          pembahasan: '',
          keputusan: '',
        },
      ],
      actionItems: [],
      catatanPenutup:
        'Demikian notulensi rapat ini dibuat dengan sebenar-benarnya untuk dipergunakan sebagaimana mestinya.',
      kotaPenetapan: 'Palopo',
      updatedAt: new Date().toISOString(),
    };

    setMinutes((prev) => [newMinute, ...prev]);
    setEditingId(newMinute.id);
    setEditorInitialMode('edit');
    setActiveNav('list');
    setMobileMenuOpen(false);
    showToast('Draf notulensi baru telah dibuat.');
  };

  const handleUpdateMinute = (updated: MeetingMinute) => {
    setMinutes((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
  };

  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    setMinutes((prev) => prev.filter((m) => m.id !== deleteTarget.id));
    if (editingId === deleteTarget.id) {
      setEditingId(null);
    }
    showToast(`Notulensi "${deleteTarget.nomorSurat || deleteTarget.judul}" dihapus.`);
    setDeleteTarget(null);
  };

  const handleDownloadHtml = (minute: MeetingMinute) => {
    downloadHtmlFile(minute);
    showToast(`File HTML "${minute.nomorSurat || 'notulen'}" berhasil diunduh.`);
  };

  const handleUpdateActionStatus = (
    minuteId: string,
    actionId: string,
    newStatus: ActionStatus
  ) => {
    setMinutes((prev) =>
      prev.map((m) => {
        if (m.id !== minuteId) return m;
        return {
          ...m,
          actionItems: m.actionItems.map((act) =>
            act.id === actionId ? { ...act, status: newStatus } : act
          ),
          updatedAt: new Date().toISOString(),
        };
      })
    );
    showToast(`Status tindak lanjut diperbarui menjadi "${newStatus}".`);
  };

  const handleResetDemoData = () => {
    setMinutes(INITIAL_MINUTES);
    setEditingId(null);
    setSelectedUnit('ALL');
    setStatusFilter('ALL');
    setSearchQuery('');
    showToast('Data contoh notulensi UMB Palopo dipulihkan.');
  };

  const totalOpenActions = useMemo(
    () =>
      minutes.reduce(
        (sum, m) => sum + m.actionItems.filter((a) => a.status !== ActionStatus.SELESAI).length,
        0
      ),
    [minutes]
  );

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Institutional Brand */}
      <div className="px-5 py-5 border-b border-slate-200 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <UniversityEmblem className="w-9 h-9 shrink-0" />
          <div className="min-w-0">
            <p className="font-serif text-sm font-bold text-[#0F294A] truncate">
              UMB Palopo
            </p>
            <p className="text-[11px] text-slate-500 truncate">Sistem Notulensi Rapat</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-1.5 text-slate-500 hover:text-slate-900 rounded-md cursor-pointer"
          aria-label="Tutup menu"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Primary Sidebar Action */}
      <div className="p-4">
        <button
          type="button"
          onClick={handleCreateNew}
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap cursor-pointer"
        >
          <FilePlus2 className="w-4 h-4" />
          <span>Buat Notulen Baru</span>
        </button>
      </div>

      {/* Main Navigation */}
      <nav className="px-3 space-y-1">
        <button
          type="button"
          onClick={() => {
            setActiveNav('list');
            setEditingId(null);
            setMobileMenuOpen(false);
          }}
          className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
            activeNav === 'list' && !editingId
              ? 'bg-slate-100 text-[#0F294A] font-semibold'
              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
          }`}
        >
          <span className="inline-flex items-center gap-2.5">
            <FileText className="w-4 h-4" />
            <span>Arsip Notulensi</span>
          </span>
          <span className="font-mono tabular-nums text-slate-500">{minutes.length}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setActiveNav('actions');
            setEditingId(null);
            setMobileMenuOpen(false);
          }}
          className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
            activeNav === 'actions' && !editingId
              ? 'bg-slate-100 text-[#0F294A] font-semibold'
              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
          }`}
        >
          <span className="inline-flex items-center gap-2.5">
            <CheckSquare className="w-4 h-4" />
            <span>Pelacak Tindak Lanjut</span>
          </span>
          <span className="font-mono tabular-nums text-amber-700">{totalOpenActions}</span>
        </button>
      </nav>

      {/* Unit Kerja Filter */}
      <div className="mt-6 px-3 flex-1 overflow-y-auto">
        <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2">
          Unit Kerja &amp; Fakultas
        </p>
        <div className="space-y-0.5">
          <button
            type="button"
            onClick={() => {
              setSelectedUnit('ALL');
              setActiveNav('list');
              setEditingId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-3 py-1.5 text-xs rounded-md transition-colors cursor-pointer ${
              selectedUnit === 'ALL' && activeNav === 'list'
                ? 'bg-[#0F294A]/5 text-[#0F294A] font-semibold'
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <span className="truncate">Semua Unit Kerja</span>
            <span className="font-mono tabular-nums text-slate-400">{minutes.length}</span>
          </button>

          {UNIT_KERJA_LIST.map((unit) => {
            const count = minutes.filter((m) => m.unitKerja === unit).length;
            const isActive = selectedUnit === unit && activeNav === 'list';
            return (
              <button
                key={unit}
                type="button"
                onClick={() => {
                  setSelectedUnit(unit);
                  setActiveNav('list');
                  setEditingId(null);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between gap-2 px-3 py-1.5 text-xs rounded-md transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#0F294A]/5 text-[#0F294A] font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <span className="truncate text-left">{unit}</span>
                <span className="font-mono tabular-nums text-slate-400 shrink-0">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer Utility */}
      <div className="p-4 border-t border-slate-200">
        <button
          type="button"
          onClick={handleResetDemoData}
          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Pulihkan Data Contoh</span>
        </button>
        <p className="text-[11px] text-slate-400 text-center mt-2">
          Universitas Mega Buana Palopo
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      {/* Desktop Sidebar (264px) */}
      <aside className="no-print hidden lg:block w-[264px] shrink-0 sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="no-print fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">{sidebarContent}</div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Contextual Header */}
        <header className="no-print sticky top-0 z-20 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg cursor-pointer"
              aria-label="Buka navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Breadcrumbs */}
            <div className="flex items-center gap-2 text-xs sm:text-sm min-w-0">
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setActiveNav('list');
                }}
                className="font-medium text-slate-500 hover:text-[#0F294A] whitespace-nowrap shrink-0 cursor-pointer"
              >
                Notulensi UMB Palopo
              </button>
              <span className="text-slate-300" aria-hidden="true">
                /
              </span>
              {activeMinute ? (
                <span className="font-mono text-xs sm:text-sm font-medium text-slate-900 truncate">
                  {activeMinute.nomorSurat || activeMinute.judul}
                </span>
              ) : activeNav === 'actions' ? (
                <span className="font-medium text-slate-900 whitespace-nowrap">
                  Pelacak Tindak Lanjut
                </span>
              ) : (
                <span className="font-medium text-slate-900 truncate">
                  {selectedUnit === 'ALL' ? 'Semua Unit Kerja' : selectedUnit}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {activeMinute ? (
              <button
                type="button"
                onClick={() => handleDownloadHtml(activeMinute)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Ekspor HTML</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCreateNew}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-[#0F294A] rounded-lg hover:bg-[#163966] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FilePlus2 className="w-3.5 h-3.5" />
                <span>Notulen Baru</span>
              </button>
            )}
          </div>
        </header>

        {/* Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-[1400px] w-full mx-auto">
          {activeMinute ? (
            <MinutesEditor
              key={activeMinute.id}
              minute={activeMinute}
              initialMode={editorInitialMode}
              onChange={handleUpdateMinute}
              onBack={() => setEditingId(null)}
              onDownloadHtml={handleDownloadHtml}
              onNotify={showToast}
            />
          ) : activeNav === 'actions' ? (
            <ActionItemsTracker
              minutes={minutes}
              onUpdateActionStatus={handleUpdateActionStatus}
              onOpenMinute={(minuteId) => {
                setEditingId(minuteId);
                setEditorInitialMode('edit');
              }}
            />
          ) : (
            <MinutesListView
              minutes={filteredMinutes}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              statusFilter={statusFilter}
              onStatusFilterChange={setStatusFilter}
              selectedUnit={selectedUnit}
              onCreateNew={handleCreateNew}
              onOpenMinute={(id, mode) => {
                setEditingId(id);
                setEditorInitialMode(mode);
              }}
              onDownloadHtml={handleDownloadHtml}
              onRequestDelete={(minute) => setDeleteTarget(minute)}
            />
          )}
        </main>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div
          className="no-print fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-modal-title"
        >
          <div className="bg-white border border-slate-200 rounded-lg max-w-md w-full p-6 space-y-4">
            <div>
              <h2 id="delete-modal-title" className="text-base font-semibold text-slate-900">
                Hapus Dokumen Notulensi?
              </h2>
              <p className="text-sm text-slate-600 mt-1.5">
                Dokumen <span className="font-medium text-slate-900">{deleteTarget.judul}</span>{' '}
                ({deleteTarget.nomorSurat || 'tanpa nomor'}) akan dihapus permanen dari penyimpanan
                peramban ini.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 text-xs font-medium text-white bg-rose-700 rounded-lg hover:bg-rose-800 transition-colors cursor-pointer"
              >
                Ya, Hapus Notulen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Non-blocking Toast */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="no-print fixed bottom-5 right-5 z-50 bg-[#0F294A] text-white text-xs sm:text-sm font-medium px-4 py-2.5 rounded-lg shadow-lg border border-[#1E4476]"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
